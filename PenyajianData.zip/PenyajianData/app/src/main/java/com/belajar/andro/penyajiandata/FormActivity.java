package com.belajar.andro.penyajiandata;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.widget.TextView;

public class FormActivity extends AppCompatActivity {
    TextView hsl_nama, hsl_nim, hsl_nilai;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_form);

        String nama = getIntent().getExtras().getString("hasil_nama");
        String nim = getIntent().getExtras().getString("hasil_nim");
        String nilai = getIntent().getExtras().getString("hasil_nilai");

        hsl_nama = findViewById(R.id.result_nama);
        hsl_nim = findViewById(R.id.result_nim);
        hsl_nilai = findViewById(R.id.result_nilai);

        hsl_nama.setText(nama);
        hsl_nim.setText(nim);
        hsl_nilai.setText(nilai);
    }
}
