package com.belajar.andro.penyajiandata;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {
    EditText edtNama;
    EditText edtNim;
    EditText edtNilai;
    Button btnSubmit;
    String hasilConvert;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        edtNama = findViewById(R.id.id_nama);
        edtNim = findViewById(R.id.id_nim);
        edtNilai = findViewById(R.id.id_ip);
        btnSubmit = findViewById(R.id.btn_id_submit);

        btnSubmit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                try {
                    String inputNama = edtNama.getText().toString().trim();
                    String inputNim = edtNim.getText().toString().trim();
                    String inputNilai = edtNilai.getText().toString().trim();

                    boolean isEmptyField = false;
                    boolean isInvalidDouble = false;

                    if (TextUtils.isEmpty(inputNama)){
                        isEmptyField = true;
                        edtNama.setError("Field ini tidak boleh kosong!");
                    }
                    if (TextUtils.isEmpty(inputNim)){
                        isEmptyField = true;
                        edtNim.setError("Field ini tidak boleh kosong!");
                    }
                    if (TextUtils.isEmpty(inputNilai)){
                        isEmptyField = true;
                        edtNilai.setError("Field ini tidak boleh kosong!");
                    }

                    double nilai = Double.parseDouble(inputNilai);

                    if (nilai <= 4 && nilai > 3.66 ){
                        hasilConvert = String.valueOf('A');
                    } else if (nilai <= 3.66 && nilai > 3.33 ){
                        hasilConvert = "A-";
                    } else if (nilai <= 3.33 && nilai > 3 ){
                        hasilConvert = "B+";
                    } else if (nilai <= 3 && nilai > 2.66 ){
                        hasilConvert = "B";
                    } else if (nilai <= 2.66 && nilai > 2.33 ){
                        hasilConvert = "B-";
                    } else if (nilai <= 2.33 && nilai > 2 ){
                        hasilConvert = "C+";
                    } else if (nilai <= 2 && nilai > 1.66 ){
                        hasilConvert = "C";
                    } else if (nilai <= 1.66 && nilai > 1.33 ){
                        hasilConvert = "C-";
                    } else if (nilai <= 1.33 && nilai > 1 ){
                        hasilConvert = "D+";
                    } else if (nilai == 1 ){
                        hasilConvert = "D";
                    } else if(nilai > 4 || nilai < 1){
                        isInvalidDouble = true;
                        edtNilai.setError("Masukkan nilai yang benar!");
                    }

                    if (!isEmptyField && !isInvalidDouble) {
                        Intent moveIntent = new Intent(MainActivity.this, FormActivity.class);
                        moveIntent.putExtra("hasil_nama", edtNama.getText().toString());
                        moveIntent.putExtra("hasil_nim", edtNim.getText().toString());
                        moveIntent.putExtra("hasil_nilai", hasilConvert);
                        startActivity(moveIntent);
                    }



                } catch (NumberFormatException nfe){
                    Toast.makeText(getApplicationContext(),"Field Tidak Boleh Kosong", Toast.LENGTH_SHORT).show();
                }
            }

//            private Double toDouble(String str) {
//                try {
//                    return Double.valueOf(str);
//                }catch (NumberFormatException e){
//                    return null;
//                }
//            }
        });
    }


}
